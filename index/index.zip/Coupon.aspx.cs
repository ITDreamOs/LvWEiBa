﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

public partial class index_Coupon : System.Web.UI.Page
{
    string userId = "oZMY8t07V1LpLYqJCsyHgPZ3KtS4";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            OnQuery();
        }
    }

    private void OnQuery()
    {
        var bllCoupon = new LVWEIBA.DAL.MemberCoupon();
        DataTable list = bllCoupon.GetMemberCouponList(" userid='" + userId + "'").Tables[0];
        StringBuilder strYsy = new StringBuilder();
        StringBuilder strWsy = new StringBuilder();
        string yhq = "";
        foreach (DataRow dr in list.Rows)
        {

            yhq = string.Format(@"   <div class='stamp'>
                <div class='divLeft'>
                    <span class='divYhq'>优惠券</span><br />
                    <span class='divYxq'>有效期至{0}</span>
                    <table class='tabMj'>
                        <tr>
                            <td>
                                满{1}元使用
                            </td>
                        </tr>
                        <tr>
                            <td>
                                单次消费使用一张
                            </td>
                        </tr>
                    </table>
                </div>
                <div class='divRight'>
                    ￥<font class='divMoney'>{2}</font></div>
            </div>", DateTime.Parse(dr["Timeout"].ToString()).ToString("yyyy-MM-dd"), dr["OrderCount"], dr["Price"]);
            if (dr["ztmc"].ToString().Equals("未使用"))
            {
                strWsy.AppendFormat(yhq);
            }
            else
            {
                strYsy.AppendFormat(yhq);
            }

        }
        this.lit_wsy.Text = strWsy.ToString();
        this.lit_ysy.Text = strYsy.ToString();
    }
}
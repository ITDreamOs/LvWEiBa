﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

public partial class index_indent_type : System.Web.UI.Page
{
    string userId = "oZMY8t07V1LpLYqJCsyHgPZ3KtS4";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            OnQuery();
        }
    }

    private void OnQuery()
    {
        string order = "";
        var bll = new LVWEIBA.DAL.order_list();
        string sql = " and user_id='" + userId + "'";
        DataTable list = bll.GetList(" 1=1 " + sql).Tables[0];
        StringBuilder strWzf = new StringBuilder();
        StringBuilder strDcx = new StringBuilder();
        StringBuilder strYwc = new StringBuilder();
        StringBuilder strDpj = new StringBuilder();
        foreach (DataRow dr in list.Rows)
        {
            order = string.Format(@" <li>
            <a href='indent_show.html'></a>
              <div class='pic'><img src='images/jx.jpg'></div>
              <div class='wz'>
                <div class='name'>{0}</div>
                <div class='jg'>￥{1} <em>数量：{2}</em></div>
                <div class='time'>{3}</div>
#btn#
              </div>
            </li>", 
                  
             dr["order_id"],
             dr["order_Price"],
             dr["porcount"],
             DateTime.Parse(dr["order_sj"].ToString()).ToString("yyyy-MM-dd"));
            switch (dr["order_zt"].ToString())
            {

                case "待支付":
                    order = order.Replace("#btn#", " <div class='state'><a href=''>去支付</a></div>");
                    strWzf.Append(order);
                    break;
                case "待出行":
                    order = order.Replace("#btn#", "");
                    strDcx.Append(order);
                    break;
                case "已结束":
                    order = order.Replace("#btn#", "");
                    strYwc.Append(order);
                    break;
                case "待评价":
                    order = order.Replace("#btn#", " <div class='state'><a href=''>去评价</a></div>");
                    strDpj.Append(order);
                    break;
            }
        }
        this.lit_wzf.Text = strWzf.ToString();
        this.lit_dcx.Text = strDcx.ToString();
        this.lit_ywc.Text = strYwc.ToString();
        this.lit_dpj.Text = strDpj.ToString();
    }
}